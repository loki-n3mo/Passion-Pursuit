import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class background0s here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class background0s extends Actor
{
    public background0s()
    {
        GreenfootImage zero = new GreenfootImage("Sprite-0004.png");
        zero.setTransparency(30);
        zero.scale(20, 20);
        setImage(zero);
    }
    public void act()
    {
        setLocation(getX(), getY() + 2);
        if (getY() >= 395)
        {
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()), 0);
        }
    }
}