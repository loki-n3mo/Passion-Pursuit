import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Instructions extends Actor
{
    private float posX = 600, posY = 500;
    
    public Instructions()
    {
        getImage().scale(486, 88);
    }
    
    public void act()
    {
        this.setLocation(Math.round(posX - Camera.posX), Math.round(posY - Camera.posY));
        if(distance(getX(),getY(), Camera.posX, Camera.posY) > 650)
        {
            getImage().setTransparency(0);
        } else
        {
            getImage().setTransparency(255);
        }
    }
    
    public int distance(float x1, float y1, float x2, float y2)
    {
        return (int)Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 1.5);
    }
    
}
