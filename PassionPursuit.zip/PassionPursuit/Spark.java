import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spark here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spark extends Actor
{
    private float velX = 0, velY = 0;
    private float posX = 0, posY = 0;
    private int time = 0;
    public Spark(float x, float y)
    {
        posX = x;
        posY = y;
        velX = (float)(Math.random() - 0.5) * 2 * 5;
        velY = (float)Math.random() * -5;
        GreenfootImage img = getImage();
        img.scale(35, 35);
    }
    
    public void act()
    {
        if(time > 100 || isAtEdge())
            getWorld().removeObject(this);
        velY += 0.2;
        posX += velX;
        posY += velY;
        setPos();
        
        time++;
    }
    
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
    }
}
