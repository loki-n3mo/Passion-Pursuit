import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayerSprite here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayerSprite extends Actor
{
    private Player player;
    public boolean leftward = true;
    private String state = "Idle";
    private int frame = 0;
    private int time;
    private GreenfootImage[] IdleImg;
    private GreenfootImage[] RunImg;
    private GreenfootImage jumpImg;
    public PlayerSprite(Player player)
    {
        this.player = player;
        IdleImg = new GreenfootImage[8];
        RunImg = new GreenfootImage[12];
        jumpImg = new GreenfootImage("JoveyJump.png");
        jumpImg.scale(75, 75);
        for(int i = 0; i < IdleImg.length; i++) {
            IdleImg[i] = new GreenfootImage("JoveyIdle" + (i + 1) + ".png");
            IdleImg[i].scale(75, 75);
        }

        for(int i = 0; i < RunImg.length; i++) {
            RunImg[i] = new GreenfootImage("JoveyRun" + (i + 1) + ".png");
            RunImg[i].scale(75, 75);
        }
        
        setImage(IdleImg[0]);
    }
    public void act()
    {
        setAnimation();
        setLocation(player.getX(), player.getY() - 25);
        if((player.velX > 0 && leftward) || (player.velX < 0 && !leftward) && !state.equals("Spin"))
        {
            getImage().mirrorHorizontally();
            if(leftward == true)
                leftward = false;
            else
                leftward = true;
        }
        if(player.grounded)
        {
            if(Math.abs(player.velX) > 4)
            {
                state = "Run";
            } else
            {
                state = "Idle";
            }
        } else
        {
            state = "Jump";
        }
        time--;
    }
    
    public void setAnimation()
    {
        if(state.equals("Idle"))
        {
            if(frame > 7)
                frame = 1;
            if(getImage() != IdleImg[frame])
            {
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
                setImage(IdleImg[frame]);
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
            }
        }
        if(state.equals("Run"))
        {
            if(frame > 11)
                frame = 1;
            if(getImage() != RunImg[frame])
            {
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
                setImage(RunImg[frame]);
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
            }
        }
        if(state.equals("Jump"))
        {
            if(getImage() != jumpImg)
            {
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
                setImage(jumpImg);
                if(!leftward)
                {
                    getImage().mirrorHorizontally();
                }
            }
        }
        if(time <= 0)
        {
            time = 4;
            frame++;
        }
    }
}
