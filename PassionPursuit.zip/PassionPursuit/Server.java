import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Server extends Actor
{
    private float posX, posY;
    public Server(int x, int y)
    {
        getImage().setTransparency(255);
        posX = x;
        posY = y;
        GreenfootImage img = getImage();
        img.scale(100, 100);
    }
    public void update()
    {
        setPos();
    }
    
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1850000, 0, 255);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}
