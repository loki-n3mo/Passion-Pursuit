import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checkpoint here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Checkpoint extends Actor
{
    private float posX = 0, posY = 0;
    public static float lastX, lastY;
    public Checkpoint(float x, float y)
    {
        posX = x;
        posY = y;
        getImage().scale(23, 44);
    }
    public void act()
    {
        setPos();
        if(isTouching(Player.class))
        {
            Greenfoot.playSound("OpenCan.wav");
            lastX = posX;
            lastY = posY;
            getWorld().addObject(new CheckParticle(posX, posY), getX(), getY());
            getWorld().removeObject(this);
        }
    }
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1500000, 0, 255);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}
