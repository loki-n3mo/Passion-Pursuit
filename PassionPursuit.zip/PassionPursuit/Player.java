import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Player extends Actor
{
    public float velX = 0;
    public float velY = 0;
    public float maxSpeed = 5;
    public float acceleration = 2;
    public boolean grounded = false;
    public static float posX = 300, posY = 200;
    private GreenfootSound jump;
    private GreenfootSound bounce;
    private GreenfootSound die;
    private boolean won = false;
    private boolean lockControls = false;
    public Player()
    {
        GreenfootImage img = getImage();
        img.setTransparency(0);
        jump = new GreenfootSound("Jump.wav");
        bounce = new GreenfootSound("Bounce.wav");
        die = new GreenfootSound("Die.wav");
    }
    public void act()
    {
        
        input();
        
        Camera.update();
        
        if(!lockControls) posY += velY;
        velY += 0.6;
        setPos();
        collision(false);

        if(!lockControls) posX += velX;
        setPos();
        collision(true);
         
        if(isTouching(Grass.class) || posY > 3000)
        {
            reset();
        }
        if(posX > 4055 && posX < 4075 && posY > 860 && posY < 890 && !won)
        {
            Greenfoot.playSound("Yay.mp3");
            won = true;
            lockControls = true;
            for(int i = 0; i < 7; i++)
            {
                getWorld().addObject(new Spark(posX, posY), getX(), getY());
            }
        }
    }
    void reset()
    {
        die.play();
        velX = 0;
        velY = 0;        
        posX = Checkpoint.lastX;
        posY = Checkpoint.lastY;
        Camera.posX = posX;
        Camera.posY = posY;
        Camera.update();
        setPos();
    }
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
    }
    void collision(boolean isX) 
    {
        int safety = 0;
        while ((isTouching(Level.class) || isTouching(Door.class) || isTouching(Platform.class)) && safety < 10) {
            if (isX) 
                posX -= Math.signum(velX);
            else     
                posY -= (velY == 0) ? 1 : Math.signum(velY) * 2;
            
            setPos();
            safety++;
        }
        if (safety > 0) {
            if (isX) 
                velX = 0;
            else {
                if (velY >= 0) 
                {
                    grounded = true;
                }
                velY = 0;
            }
        } 
        else if(!isX && (velY < -2 || velY > 2))
        {
            grounded = false;
        }
    }
    void input()
    {
        if(Greenfoot.isKeyDown("Up") && grounded && velY == 0)
        {
            jump.play();
            velY = -10;
        }
        
        if(Greenfoot.isKeyDown("Left") && velX > -maxSpeed)
        {
            velX += -acceleration;
        }
        if(Greenfoot.isKeyDown("Right") && velX < maxSpeed)
        {
            velX += acceleration;
        }
        if(!(Greenfoot.isKeyDown("Right") || Greenfoot.isKeyDown("Left")))
        {
            velX *= 0.6;
        }
        if(Math.abs(velX) < 1.5)
        {
            velX = 0;
        }
    }
}
