import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checkpoint here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Actor
{
    public float posX = 2150, posY = 503;
    private float openY;
    public boolean open = false;
    public Door(float X, float Y)
    {
        posX = X;
        posY = Y;   
        openY = posY + 75;
        getImage().scale(72, 72);
    }
    public void act()
    {
        if(open && openY - posY > 1)
        {
            posY += (openY - posY) / 25;
        }
    }
    public void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1500000, 0, 255);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}
