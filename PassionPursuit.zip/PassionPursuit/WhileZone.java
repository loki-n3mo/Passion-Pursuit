import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checkpoint here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WhileZone extends Actor
{
    private float posX = 0, posY = 0;
    private float time;
    public WhileZone(float x, float y)
    {
        posX = x;
        posY = y;
        getImage().scale(120, 80);
    }
    public void act()
    {
        if(isTouching(Player.class) && time <= 0)
        {
            int randomX = Greenfoot.getRandomNumber(300) - 150;
            int randomY = Greenfoot.getRandomNumber(80);
            getWorld().addObject(new Checkpoint(posX + randomX, posY - randomY), 0, 0);
            time = 100;
        }
        if(time > 0)
        {
            time--;
        }
        setPos();
    }
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1500000, 0, 150);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}
