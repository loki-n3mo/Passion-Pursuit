import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
public class Camera extends Actor
{
    public static float posX = 0, posY = 0;
    public static List<Level> blocks;
    public static List<Grass> grasses;
    public static List<Server> servers;
    public static List<Door> doors;
    public static List<Platform> platforms;
    private static PlayerSprite spit;
    
    public Camera(PlayerSprite sprit)
    {
        spit = sprit;
    }
    public static void update()
    {
        //int leftward = spit.leftward? -1 : 1;
        posX += (Player.posX - 300 - posX) / 7;
        posY += (Player.posY - 200 - posY) / 5;
        for(Level block : blocks)
        {
            block.update();
        }
        for(Grass grass : grasses)
        {
            grass.update();
        }
        for(Server server : servers)
        {
            server.update();
        }
        for(Door door : doors)
        {
            door.setPos();
        }
        for(Platform plat : platforms)
        {
            plat.setPos();
        }
    }
}
