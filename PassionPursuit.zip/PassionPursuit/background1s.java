import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class background1s extends Actor
{
    public background1s()
    {
        GreenfootImage zero = new GreenfootImage("Sprite-0005.png");
        zero.setTransparency(30);
        zero.scale(20, 20);
        setImage(zero);
    }
    public void act()
    {
        setLocation(getX(), getY() + 2);
        if (getY() >= 395)
        {
            setLocation(Greenfoot.getRandomNumber(getWorld().getWidth()), 0);
        }
    }
}