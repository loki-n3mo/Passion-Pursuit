import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checkpoint here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DoorSwitch extends Actor
{
    private float posX = 2000, posY = 525;
    private float pressedY;
    private Door door;
    private int ID;
    public DoorSwitch(Door door, int ID)
    {
        this.door = door;
        this.ID = ID;
        
        if(ID == 1)
        {
            posX = 2175;
            posY = 825;
            setImage(new GreenfootImage("SpawnMonsters.png"));
            getImage().scale(90, 72/3);
        } else if(ID == 0){
            posX = 2000;
            posY = 525;
            setImage(new GreenfootImage("DoorSwitch.png"));
            getImage().scale(72, 72/3);
        } else if(ID == 2)
        {
            posX = 1950;
            posY = 825;            
            setImage(new GreenfootImage("DoorSwitch.png"));
            getImage().scale(72, 72/3);
        }
        pressedY = posY + 10;
    }
    public void act()
    {
        if(isTouching(Player.class) && door != null)
        {
            posY += 1;
            if(posY == pressedY)
            {
                Greenfoot.playSound("Button.wav");
                door.open = true;
            }
        }
        if(isTouching(Player.class) && ID == 1)
        {
            posY += 1;
            if(posY == 840)
            {
                getWorld().addObject(new Checkpoint(posX - 100, posY - 30), 0, 0);
            }
        }
        setPos();
    }
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1500000, 0, 255);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}
