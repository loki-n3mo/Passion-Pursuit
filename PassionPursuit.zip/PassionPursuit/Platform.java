import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checkpoint here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Platform extends Actor
{
    private float posX = 0, posY = 0;
    private int num;
    private boolean activated = false;
    public Platform(float x, float y, int num)
    {
        posX = x;
        posY = y;
        this.num = num;
        setImage(new GreenfootImage("Platforms" + (num + 1) + ".png"));
        getImage().setTransparency(100);
        getImage().scale(80, 20);
    }
    
    public void act()
    {
        if(isTouching(PlayerSprite.class) && !activated)
        {
            Collide();
        }
    }
    public void Collide()
    {
        activated = true;
        switch(num)
        {
            case 0:
                getWorld().addObject(new Platform(posX + 200, posY + 50, 1), 0, 0);
                break;
            case 1:
                getWorld().addObject(new Platform(posX + 200, posY + 100, 2), 0, 0);
                break;
            case 2:
                getWorld().addObject(new Platform(posX + 250, posY - 50, 3), 0, 0);
                break;
            case 3:
                getWorld().addObject(new Platform(posX + 100, posY - 75, 4), 0, 0);
                break;
            case 4:
                getWorld().addObject(new Platform(posX + 200, posY +50, 5), 0, 0);
                break;
            case 5:
                break;
        }
        ((MyWorld)getWorld()).updatePlatforms();
    }
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
        double dist = distance(posX, posY, Camera.posX, Camera.posY);
        int value = (int)Math.clamp(dist * dist * dist / 1500000, 0, 255);
        getImage().setTransparency(255 - value);
    }
    
    public double distance(float x1, float y1, float x2, float y2)
    {
        return Math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1) * 2);
    }
}