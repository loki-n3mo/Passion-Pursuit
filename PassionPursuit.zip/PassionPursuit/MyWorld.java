import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

public class MyWorld extends World
{
    private String[] level = {"000000000000000000000000000000",
                              "100000000000000000000000010001",
                              "100000000000000000000000010001",
                              "100000000000000000000000010001",
                              "100000000000000001100400000001",
                              "100004000112212211111111111001",
                              "111111111110000010001000000001",
                              "000000000000000010001000000001000000000000000000000001",
                              "000000000000000010000000004001000000000000000000000001",
                              "000000000000000010001111111111000000000000000000400001",
                              "000000000000000000000000000000000000000000000001111111",
                              "000000000000000000000000000000000400000000010011",
                              "000000000000000000000000000000001111111122112211"
                            };
    private Camera camera;
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        GreenfootImage img = new GreenfootImage("Background.png");
        img.scale(300, 200);
        setBackground(img);
        Player.posX = 400; //400 //2300
        Player.posY = 600; //600 //800
        Camera.posX = 0;
        Camera.posY = 0;
        Checkpoint.lastX = 400;
        Checkpoint.lastY = 600;
        Player player = new Player();
        create01s(40);
        setPaintOrder(PlayerSprite.class,Level.class, Grass.class, Server.class);
        addObject(player, 400, 300);
        Door door1 = new Door(2150, 503);
        Door door2 = new Door(1800, 800);
        addObject(door1, 400, 300);
        addObject(door2, 400, 300);
        addObject(new DoorSwitch(door1, 0), 500, 300);
        addObject(new DoorSwitch(door2, 2), 2100, 800);
        addObject(new DoorSwitch(null, 1), 2175, 800);
        addObject(new PlayerSprite(player), 400, 300);
        for(int i = 0; i < level.length; i++)
        {
            for(int j = 0; j < level[i].length(); j++)
            {
                if(level[i].charAt(j) == '1')
                {
                    addObject(new Level(300 + j * 75, 200 + i * 75), 0, 0);
                } else if(level[i].charAt(j) == '2')
                {
                    addObject(new Grass(300 + j * 75, 200 + i * 75), 0, 0);
                } else if(level[i].charAt(j) == '3')
                {
                    addObject(new Checkpoint(300 + j * 75, 200 + i * 75), 0, 0);
                }else if(level[i].charAt(j) == '4')
                {
                    addObject(new Server(300 + j * 75, 200 + i * 75), 0, 0);
                } else if(level[i].charAt(j) == 'X')
                {
                    System.out.println(300 + j * 75);
                    System.out.println(200 + i * 75);
                }
            }
        }
        
        addObject(new Platform(1650, 1025, 0), 0, 0);
        addObject(new WhileZone(3000, 1025), 425, 100);
        addObject(new Instructions(), 425, 100);
        addObject(new Winner(4125, 875), 0, 0);
        camera = new Camera(getObjects(PlayerSprite.class).get(0));
        addObject(camera, 300, 200);
        camera.getImage().setTransparency(0);
        camera.blocks = getObjects(Level.class);
        camera.grasses = getObjects(Grass.class);
        camera.servers = getObjects(Server.class);
        camera.doors = getObjects(Door.class);
        camera.platforms = getObjects(Platform.class);
        camera.update();
    }
    public void updatePlatforms()
    {
        camera.platforms = getObjects(Platform.class);
    }
    public void create01s(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int x = Greenfoot.getRandomNumber(getWidth());
            int x2 = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            int y2 = Greenfoot.getRandomNumber(getHeight());
            addObject(new background0s(), x, y);
            addObject(new background1s(), x2, y2);
        }
    }
}
