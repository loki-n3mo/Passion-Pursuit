import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class checkParticle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CheckParticle extends Actor
{
    private float velY = 0;
    private float posX = 0, posY = 0;
    private int time = 0;
    private GreenfootImage img;
    public CheckParticle(float x,float y)
    {
        posX = x;
        posY = y;
        velY = (float)(Math.random() + 1) * -3;
        img = getImage();
        img.scale(150, 75);
    }
    
    public void act()
    {
        if(time > 50 || isAtEdge())
            getWorld().removeObject(this);
        velY /= 1.2;
        posY += velY;
        setPos();
        img.setTransparency(255 - time * 3);
        time+=2;
    }
    
    void setPos()
    {
        this.setLocation(Math.round(posX) - (int)Camera.posX, Math.round(posY) - (int)Camera.posY);
    }
}
